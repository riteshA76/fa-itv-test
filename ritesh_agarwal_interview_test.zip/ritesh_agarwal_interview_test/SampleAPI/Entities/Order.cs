﻿using System.ComponentModel.DataAnnotations;

namespace SampleAPI.Entities
{
    public class Order
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public DateTime EntryDate { get; set; }

        [Required]
        [MaxLength(100)]
        public string? Name { get; set; }

        [Required]
        [MaxLength(100)]
        public string? Description { get; set; }

        public bool Invoiced { get; set; } = true;

        public bool Deleted { get; set; } = false;
    }
}
