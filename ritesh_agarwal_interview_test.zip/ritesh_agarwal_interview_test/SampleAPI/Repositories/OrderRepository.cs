﻿using Microsoft.EntityFrameworkCore;
using SampleAPI.Entities;
using SampleAPI.Requests;
using SampleAPI.Logging;

namespace SampleAPI.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly SampleApiDbContext _dbContext;
        private readonly ILogger<OrderRepository> _logger;

        public OrderRepository(SampleApiDbContext dbContext, ILogger<OrderRepository> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task<List<Order>> GetRecentOrders()
        {
            try
            {
                var oneDayAgo = DateTime.UtcNow.AddDays(-1);
                return await _dbContext.Orders
                    .Where(o => o.EntryDate > oneDayAgo && !o.Deleted)
                    .OrderByDescending(o => o.EntryDate)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, LogMessages.FetchRecentOrdersError);
                throw;
            }
        }

        public async Task<Order> AddNewOrder(CreateOrderRequest request)
        {
            try
            {
                var order = new Order
                {
                    Id = Guid.NewGuid(),
                    EntryDate = DateTime.UtcNow,
                    Name = request.Name,
                    Description = request.Description,
                    Invoiced = request.Invoiced ?? true
                };

                _dbContext.Orders.Add(order);
                await _dbContext.SaveChangesAsync();

                return order;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, LogMessages.AddNewOrderError);
                throw;
            }
        }
    }
}
