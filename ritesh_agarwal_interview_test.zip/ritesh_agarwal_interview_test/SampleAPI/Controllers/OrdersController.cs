﻿using Microsoft.AspNetCore.Mvc;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;
using SampleAPI.Logging;


namespace SampleAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly ILogger<OrdersController> _logger;
        // Add more dependencies as needed.

        public OrdersController(IOrderRepository orderRepository, ILogger<OrdersController> logger)
        {
            _orderRepository = orderRepository;
            _logger = logger;
        }

        [HttpGet("recent")] // TODO: Change route, if needed.
        [ProducesResponseType(StatusCodes.Status200OK)] // TODO: Add all response types
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]

        public async Task<ActionResult<List<Order>>> GetRecentOrders()
        {
            try
            {
                var orders = await _orderRepository.GetRecentOrders();

                if (orders == null || !orders.Any())
                {
                    return NotFound();
                }

                _logger.LogInformation(LogMessages.FetchRecentOrdersSuccess);
                return Ok(orders);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, LogMessages.FetchRecentOrdersError);
                return StatusCode(StatusCodes.Status500InternalServerError, LogMessages.FetchRecentOrdersError);
            }
        }

        /// TODO: Add an endpoint to allow users to create an order using <see cref="CreateOrderRequest"/>.

        [HttpPost("")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<Order>> CreateOrder([FromBody] CreateOrderRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var order = await _orderRepository.AddNewOrder(request);
                _logger.LogInformation(LogMessages.AddNewOrderSuccess(order.Id.ToString()));
                return CreatedAtAction(nameof(GetRecentOrders), new { id = order.Id }, order);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, LogMessages.AddNewOrderError);
                return StatusCode(StatusCodes.Status500InternalServerError, LogMessages.AddNewOrderError);
            }
        }
    }
}
