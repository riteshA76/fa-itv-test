namespace SampleAPI.Logging
{
    public static class LogMessages
    {
        // Log messages for fetching recent ordders
        public static string FetchRecentOrdersError => "An error occurred while fetching recent orders.";
        public static string FetchRecentOrdersSuccess => "Successfully retrieved recent orders.";

        // Log messages for adding new orders
        public static string AddNewOrderSuccess(string orderId) => $"Successfully added a new order with ID: {orderId}.";
        public static string AddNewOrderError => "An error occurred while adding a new order.";

        // General exception logging
        public static string GeneralError(string methodName) => $"An error occurred in method {methodName}.";
    }
}
