using Microsoft.EntityFrameworkCore;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;

namespace SampleAPI.Tests.Repositories
{
    public class OrderRepositoryTests : IAsyncLifetime
    {
        private readonly SampleApiDbContext _dbContext;
        private readonly OrderRepository _orderRepository;

        public OrderRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<SampleApiDbContext>()
                .UseInMemoryDatabase("TestDatabase")
                .Options;

            _dbContext = new SampleApiDbContext(options);
            _orderRepository = new OrderRepository(_dbContext, Mock.Of<ILogger<OrderRepository>>());
        }

        public async Task InitializeAsync()
        {
            _dbContext.Orders.RemoveRange(_dbContext.Orders);
            await _dbContext.SaveChangesAsync();
        }

        public Task DisposeAsync() => Task.CompletedTask;

        [Fact]
        public async Task GetRecentOrders_ShouldReturnRecentOrders()
        {
            _dbContext.Orders.AddRange(
                new Order { Id = Guid.NewGuid(), Name = "Order 1", Description = "Description 1", EntryDate = DateTime.UtcNow.AddHours(-1), Deleted = false },
                new Order { Id = Guid.NewGuid(), Name = "Order 2", Description = "Description 2", EntryDate = DateTime.UtcNow.AddHours(-2), Deleted = false }
            );
            await _dbContext.SaveChangesAsync();

            var orders = await _orderRepository.GetRecentOrders();

            orders.Should().HaveCount(2);
        }

        [Fact]
        public async Task GetRecentOrders_ShouldNotReturnDeletedOrders()
        {
            _dbContext.Orders.AddRange(
                new Order { Id = Guid.NewGuid(), Name = "Order 1", Description = "Description 1", EntryDate = DateTime.UtcNow.AddHours(-1), Deleted = false },
                new Order { Id = Guid.NewGuid(), Name = "Order 2", Description = "Description 2", EntryDate = DateTime.UtcNow.AddHours(-2), Deleted = true }
            );
            await _dbContext.SaveChangesAsync();

            var orders = await _orderRepository.GetRecentOrders();

            orders.Should().HaveCount(1);
        }

        [Fact]
        public async Task AddNewOrder_ShouldAddOrderSuccessfully()
        {
            var request = new CreateOrderRequest { Name = "New Order", Description = "New Order Description", Invoiced = true };

            var order = await _orderRepository.AddNewOrder(request);

            order.Should().NotBeNull();
            order.Name.Should().Be(request.Name);
            order.Description.Should().Be(request.Description);
            order.Invoiced.Should().BeTrue();
        }

        [Fact]
        public async Task AddNewOrder_ShouldThrowExceptionOnFailure()
        {
            var request = new CreateOrderRequest { Name = "New Order", Description = "New Order Description", Invoiced = true };

            var mockDbContext = new Mock<SampleApiDbContext>(new DbContextOptions<SampleApiDbContext>());
            var mockDbSet = new Mock<DbSet<Order>>();

            mockDbContext.Setup(db => db.Orders).Returns(mockDbSet.Object);
            mockDbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>())).ThrowsAsync(new Exception("Test Exception"));

            var orderRepository = new OrderRepository(mockDbContext.Object, Mock.Of<ILogger<OrderRepository>>());

            await Assert.ThrowsAsync<Exception>(() => orderRepository.AddNewOrder(request));
        }
    }
}