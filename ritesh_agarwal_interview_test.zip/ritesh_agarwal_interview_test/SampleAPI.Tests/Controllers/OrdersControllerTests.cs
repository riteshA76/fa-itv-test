﻿using Microsoft.AspNetCore.Mvc;
using SampleAPI.Controllers;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;

namespace SampleAPI.Tests.Controllers
{
    public class OrdersControllerTests
    {
        private readonly Mock<IOrderRepository> _mockOrderRepository;
        private readonly Mock<ILogger<OrdersController>> _mockLogger;
        private readonly OrdersController _controller;

        public OrdersControllerTests()
        {
            _mockOrderRepository = new Mock<IOrderRepository>();
            _mockLogger = new Mock<ILogger<OrdersController>>();
            _controller = new OrdersController(_mockOrderRepository.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task GetRecentOrders_ShouldReturnOk_WhenOrdersExist()
        {
            var orders = new List<Order>
            {
                new Order { Id = Guid.NewGuid(), Name = "Order 1", Description = "Description 1", EntryDate = DateTime.UtcNow },
                new Order { Id = Guid.NewGuid(), Name = "Order 2", Description = "Description 2", EntryDate = DateTime.UtcNow }
            };
            _mockOrderRepository.Setup(repo => repo.GetRecentOrders()).ReturnsAsync(orders);

            var result = await _controller.GetRecentOrders();

            var okResult = result.Result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.Value.Should().BeEquivalentTo(orders);
        }

        [Fact]
        public async Task GetRecentOrders_ShouldReturnInternalServerError_WhenExceptionThrown()
        {
            _mockOrderRepository.Setup(repo => repo.GetRecentOrders()).ThrowsAsync(new Exception("Test Exception"));

            var result = await _controller.GetRecentOrders();

            var objectResult = result.Result as ObjectResult;
            objectResult.Should().NotBeNull();
            objectResult!.StatusCode.Should().Be(500);
        }

        [Fact]
        public async Task CreateOrder_ShouldReturnCreated_WhenValidRequest()
        {
            var request = new CreateOrderRequest { Name = "New Order", Description = "New Order Description", Invoiced = true };
            var createdOrder = new Order { Id = Guid.NewGuid(), Name = request.Name, Description = request.Description, EntryDate = DateTime.UtcNow };
            _mockOrderRepository.Setup(repo => repo.AddNewOrder(request)).ReturnsAsync(createdOrder);

            var result = await _controller.CreateOrder(request);

            var createdAtActionResult = result.Result as CreatedAtActionResult;
            createdAtActionResult.Should().NotBeNull();
            createdAtActionResult!.Value.Should().BeEquivalentTo(createdOrder);
        }

        [Fact]
        public async Task CreateOrder_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            _controller.ModelState.AddModelError("Name", "The Name field is required");

            var result = await _controller.CreateOrder(new CreateOrderRequest());

            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
        }

        [Fact]
        public async Task CreateOrder_ShouldReturnInternalServerError_WhenExceptionThrown()
        {
            var request = new CreateOrderRequest { Name = "New Order", Description = "New Order Description", Invoiced = true };
            _mockOrderRepository.Setup(repo => repo.AddNewOrder(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await _controller.CreateOrder(request);

            var objectResult = result.Result as ObjectResult;
            objectResult.Should().NotBeNull();
            objectResult!.StatusCode.Should().Be(500);
        }
    }
}
